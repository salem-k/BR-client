// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
var battelierrecords = angular.module('starter', ['ionic','ionic.service.core','ngCordova', 'ionic.service.push'])

.run(function($ionicPlatform,$ionicPush) {

  $ionicPlatform.ready(function() {

//###########################################################################################
    Ionic.io();

    $ionicPush.init({
      "debug": true,
      "onNotification": function(notification) {



        console.warn(JSON.stringify(notification));

      },
      "onRegister": function(data) {
        console.warn(JSON.stringify(data));
      }
    });
    $ionicPush.register();
//###########################################################################################

    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    .state('login', {
          url: '/login',
          views: {
            'content': {
              templateUrl: 'templates/login.html'
            }
          }
        })
  .state('homepage', {
              url: '/homepage',
              views: {
                'content': {
                  templateUrl: 'templates/homepage.html'
                }
              }
            });

$urlRouterProvider.otherwise('/login');


});
